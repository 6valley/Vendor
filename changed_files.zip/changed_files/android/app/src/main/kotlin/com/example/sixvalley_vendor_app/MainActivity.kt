package com.example.sixvalley_vendor_appp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
